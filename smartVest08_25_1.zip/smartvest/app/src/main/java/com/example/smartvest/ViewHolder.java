package com.example.smartvest;

import android.widget.Button;
import android.widget.TextView;

public class ViewHolder {

    TextView tv_company, tv_w_name, tv_work, tv_edu, tv_in_out;
    TextView tv_title;
    TextView tv_date;
    Button btn_live;


}
