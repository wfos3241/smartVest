package com.example.smartvest;

public class UserVO {
    private double longitude;
    private float latitude;
    private float altitude;

    public UserVO(double longitude, float latitude, float altitude) {

        this.longitude = longitude;
        this.latitude = latitude;
        this.altitude = altitude;
    }

    public UserVO(double longitude, double latitude, double altitude) {

        this.longitude = longitude;
        this.latitude = (float)latitude;
        this.altitude = (float)altitude;
    }
    public UserVO() {
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getAltitude() {
        return altitude;
    }

    public void setAltitude(float altitude) {
        this.altitude = altitude;
    }
}
